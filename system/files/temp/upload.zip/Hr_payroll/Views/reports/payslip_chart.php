<div class="payslip_chart hide" >
   <div id="payslip_chart" class="reports" ></div>
</div>