<style type="text/css">
	.align_left{
	text-align: left;
}
.align_right{
	text-align: right;
}
.avartar_w_h{
	width: 200px;
	height: 280px;
}
.text_align_center{
	text-align: center;
}
.text_align_justify{
	text-align: justify;
}
.av_margin_left{
	padding-left: 100px;
}


.border_table{
	border: 1px solid #000000!important;
	
}

.experience_boder{
	margin: 50px!important; 
}
.candidate_name_color{
	color: black; 
}
.position_color{
	color: black; 
}
.candidate_code_color{
	color: black; 
}

.summary_title{
	color: black; 
	font-size: 19px;

}

.introduce_yourself{
	color: black; 
	font-size: 15px;

}

.employment_record_title{
	color: black; 
	font-size: 19px;

}
.record_title{
	color: black; 
	font-size: 17px;
	font-weight: bold;

}
.record_content{
	color: black; 
	font-size: 15px;

}

.employment_literacy_title{
	color: black; 
	font-size: 19px;

}
.literacy_title{
	color: black; 
	font-size: 17px;
	font-weight: bold;

}
.literacy_content{
	color: black; 
	font-size: 15px;

}
.skill_name{
	border: 1px solid black;
	padding: 10px
}

.logo_width{
	width: 150px;
}

.candidate_name_widt_27{
	width: 27%;
}
.logo_with{
	width: 73%;
}
.avatar_width_30{
	width: 27%;
}
.qualifications_width_70{
	width: 70%;
}
.td_width_100{
	width: 100%;
}
.td_width_2{
	width: 2%;
}
.td_width_15{
	width: 15%;
}
.td_width_38{
	width: 38%;
}
.td_width_27{
	width: 27%;
}
.td_width_96{
	width: 96%;
}


.font_td_cpn{
	font-weight: 500;
	width: 30%;
}
.td_ali_font{
    text-align: center;
    font-weight: 500;
}
.h2_style{
	font-size: 35px;
	margin-top: 20px;
    margin-bottom: 10px;
}
.align_cen{
	text-align: center;
}
.font_500{
	font-weight: 500;
}
.th_width_7{
	border:1px solid black;
	font-weight: bold;
	font-size: 11px;
}
.th_style{
	border:1px solid black;
	font-size: 10px;
}
.th_width_25{
	border:1px solid black; 
	width: 25%;
}
.th_width_20{
	border:1px solid black; 
	width: 20%;
}
.th_width_10{
	border:1px solid black; 
	width: 10%;
}
.th_width_17{
	border:1px solid black; 
	width: 17%;
}
.th_spe{
	text-align:center !important; 
	border:1px solid black; 
	width: 20%;
}
.th_width_15{
	border:1px solid black; 
	width: 15%;
}
.td_style_r{
	text-align: right; 
	border:1px solid black;
	font-size: 10px;
}
.width_27{
	width: 27%;
}
.fw_width35{
	font-weight: 500; width: 35%;
}
.fw_width30{
	font-weight: 500; width: 30%;
}
.ali_r_width30{
	text-align: right; width: 30%;
}
.fstyle{
	font-style: italic;
}
.width{
	width: 21%;
}
.th_style_stk{
	text-align:center;
	border-top:1px solid black;
	border-left:1px solid black;
	border-bottom:1px solid black;
	font-weight:bold;width: 5%;
}
.th_stk10{
	text-align:center;
	border-top:1px solid black;
	border-left:1px solid black;
	border-bottom:1px solid black;
	font-weight:bold;
	width: 10%;
}
.th_stk7{
	text-align:center;
	border-top:1px solid black;
	border-left:1px solid black;
	border-bottom:1px solid black;
	font-weight:bold;width: 7%;
}
.th_stk17{
	text-align:center;
	border-top:1px solid black;
	border-left:1px solid black;
	border-bottom:1px solid black;
	font-weight:bold;width: 17%;
}
.th_r_stk17{
	text-align:center; 
	border-top:1px solid black;
	border-left:1px solid black;
	border-bottom:1px solid black;
	border-right:1px solid black;
	font-weight:bold;width: 17%;"
}
.td_w5{
	border-left:1px solid black;
	border-bottom:1px solid black;
	width: 5%;
}
.td_w10{
	border-left:1px solid black;
	border-bottom:1px solid black;
	width: 10%;
}
.td_stk_w7{
	border-left:1px solid black;
	border-bottom:1px solid black;
	width: 7%;"
}
.td_stkw5{
	border-left:1px solid black;
	border-bottom:1px solid black;
	font-weight:bold;width: 5%;
	font-size:11px;
	text-align:center;
}
.td_stkw12{
	border-left:1px solid black;
	border-bottom:1px solid black;
	font-weight:bold;width: 12%;
	font-size:11px;
	text-align:center;
}
.td_stkw12s{
	border-left:1px solid black;
	border-bottom:1px solid black;
	border-right:1px solid black;
	font-weight:bold;width: 12%;
	font-size:11px;
	text-align:center;
}
.border_td{
	border-left:1px solid black;
	border-bottom:1px solid black;
}
.bor_alir{
	text-align: right;
	border-left:1px solid black;
	border-bottom:1px solid black;
}
.bor_r{
	text-align: right; 
	border-left:1px solid black;
	border-bottom:1px solid black;
	border-right:1px solid black;
}
.th_stk_style{
	text-align: right; 
	border-left:1px solid black;
	border-bottom:1px solid black;
	font-weight:bold;
}
.th_st_spe{
	text-align: right; 
	border-left:1px solid black;
	border-bottom:1px solid black;
	border-right:1px solid black;
	font-weight:bold;"
}
.wf60{
	width: 60%; 
	font-style: italic;
}
.width60{
	width: 60%;
}
.width40{
	width: 40%;
}
.td_text{
	text-align:center;
	border:1px solid black;
	font-weight:bold;
}
.border_1{
	border:1px solid black;
}
.td_text_r{
	text-align:right;
	border:1px solid black;
	font-weight:bold;
}
.div_disp{
	display:flex; 
	justify-content:flex-end;
}
.th_border_17{
	border:1px solid black; 
	font-size: 11px;
}
.font_td_cpn{
	font-weight: 500;width: 40%;
}
img {
    width: auto;
    height: 34px;
    margin-top: 3px;
}
.text_right{
	text-align:right;
}
.text_right_weight{
	font-weight: 500;
	text-align:right;

}

.thead-dark {
	background-color: #2d2d2d;
    color: #fff;
    font-weight: 500;
}

.th_border_ep{
	border:1px solid black; 
	font-size: 13px;
}
.td_style_r_ep{
	text-align: right; 
	font-size: 13px;
}
.td_style_r_ep_c{
	text-align: center; 
	font-size: 13px;
}

.bill_to_color{
	color:#424242;
}

.thead-dark-ip {
	background-color: #2d2d2d;
    color: #fff;
    font-weight: 500;
    font-size: 14px;
}
.note-align {
   text-align: justify;
}

span.print-item {
    padding: 0px 70px;
}

span.print-item-code {
    padding: 0px 70px;
    margin-top: -12px;
}

span.print-item-name {
    font-size: 11px;
    font-weight: bold;
}

span.print-item-price {
	padding: 0px 70px;
    margin-top: -8px;
   font-size: 12px;
    font-weight: bold;
    margin-bottom: 3px;

}

span.print-barcode-td-height{
	height: 50px;
}

.row.row-print-item {
    padding: 50px 0px;
}

.row.row-print-item {
    display: flex;
}

.column {
  float: left;
  width: 20%;
  padding: 10px;
  height: 300px;
  margin:0px 10px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
  margin: 10px 0px
}

.width-100-height-55{
	width:100%;
	height:55px;
}
.height-27{
	height:27px;
}

.width-20-height-27{
	width:20%;
	height:27px;
}

.width-30-height-27{
	width:30%;
	height:27px;
}
</style>

<table class="table">
	<tbody>
		<tr>
			<td width="15%"  class="text_align_center candidate_name_widt_27">
				<img src="<?php echo get_file_from_setting("invoice_logo", true); ?>" />
			</td>
			<td width="85%" class="text_align_center logo_with" >
				<?php
				echo company_widget(get_default_company_id());
				?>
			</td>
		</tr>
	</tbody>
</table>

<div class="text_align_center">
	<b><h3><?php echo app_lang('hrp_payslip_for').' '. date('M-Y', strtotime($payslip_detail['month'])); ?> </h3></b>
</div>



<table border="1" class="width-100-height-55" >
	<tbody>
		<tr class="height-27">
			<td class="width-20-height-27 align_left" ><strong><?php echo app_lang('employee_name') ; ?></strong></td>
			<td class="width-30-height-27" ><?php echo html_entity_decode($payslip_detail['employee_name']); ?></td>
			<td class="width-20-height-27" ><strong><?php echo app_lang('income_tax_number') ; ?></strong></td>
			<td class="width-30-height-27" ><?php echo html_entity_decode(isset($employee['income_tax_number']) ? $employee['income_tax_number'] : '') ?></td>
		</tr>

		<tr class="height-27">
			<td class="width-20-height-27 align_left" ><strong><?php echo app_lang('job_title') ; ?></strong></td>
			<td class="width-30-height-27" ><?php echo html_entity_decode(isset($employee['job_title']) ? $employee['job_title'] : '') ?></td>
			<td class="width-20-height-27" ><strong><?php echo app_lang('hrp_worked_day') ; ?></strong></td>
			<td class="width-30-height-27" ><?php echo to_decimal_format((float)$payslip_detail['actual_workday']+(float)$payslip_detail['actual_workday_probation']) ?></td>
		</tr>

		<tr class="height-27">
			<td class="width-20-height-27 align_left" ><strong><?php echo app_lang('staff_departments') ; ?></strong></td>
			<td class="width-30-height-27"><?php echo html_entity_decode($list_department) ?></td>
			<td class="width-20-height-27" ><strong><?php echo app_lang('paid_leave') ; ?></strong></td>
			<td class="width-30-height-27"><?php echo html_entity_decode($payslip_detail['paid_leave']); ?></td>
		</tr>
		<tr class="height-27">
			<td class="width-20-height-27 align_left" ><strong><?php echo app_lang('ps_pay_slip_number') ; ?></strong></td>
			<td class="width-30-height-27" ><?php echo html_entity_decode($payslip_detail['pay_slip_number']); ?></td>
			<td class="width-20-height-27" ><strong><?php echo app_lang('unpaid_leave') ; ?></strong></td>
			<td class="width-30-height-27" ><?php echo html_entity_decode($payslip_detail['unpaid_leave']); ?></td>
		</tr>
		
	</tbody>
</table>

<?php 
	$hrp_payslip_salary_allowance = hrp_payslip_json_data_decode($payslip_detail['json_data']);
	
 ?>
<div class="row">
	<div class="col-md-6">
		<?php if((float)($payslip_detail['actual_workday_probation']) > 0){ ?>
			<table class="table">
				<tbody>
					<tr>
						<th  class=" thead-dark"><?php echo app_lang('hrp_probation_contract'); ?></th>
						<th  class=" thead-dark"></th>
					</tr>

					<?php echo isset($hrp_payslip_salary_allowance['probation_contract_list']) ? $hrp_payslip_salary_allowance['probation_contract_list'] : '' ?>
				</tbody>
			</table>
		<?php } ?>
		
		<?php if((float)($payslip_detail['actual_workday']) > 0){ ?>
		<table class="table">
			<tbody>
				<tr>
					<th  class=" thead-dark"><?php echo app_lang('hrp_formal_contract'); ?></th>
					<th  class=" thead-dark"></th>
				</tr>

				<?php echo isset($hrp_payslip_salary_allowance['formal_contract_list']) ? $hrp_payslip_salary_allowance['formal_contract_list'] : '' ?>
			</tbody>
		</table>
		<?php } ?>


	</div>
</div>

<div class="row">
	<div class="col-md-6">

		<table class="table">
			<tbody>
				<tr>
					<th  class=" thead-dark"><?php echo app_lang('Earnings'); ?></th>
					<th  class=" thead-dark"><?php echo app_lang('hrp_amount'); ?></th>
				</tr>

				<tr class="project-overview">
					<td  width="30%" ><?php echo app_lang('ps_gross_pay'); ?></td>
					<td class="text-left"><?php echo html_entity_decode(isset($payslip_detail) ?  to_decimal_format($payslip_detail['gross_pay'], '') : 0); ?></td>
				</tr>
				<tr class="project-overview">
					<td ><?php echo app_lang('commission_amount'); ?></td>
					<td><?php echo (isset($payslip_detail) ? to_decimal_format($payslip_detail['commission_amount']) : 0); ?></td>
				</tr>

				<tr class="project-overview">
					<td ><?php echo app_lang('ps_bonus_kpi'); ?></td>
					<td><?php echo isset($payslip_detail) ? to_decimal_format($payslip_detail['bonus_kpi']) : 0; ?></td>
				</tr>
				<tr class="project-overview">
					<td class="bold" ><?php echo app_lang('total'); ?></td>
					<td><?php echo isset($payslip_detail) ? to_decimal_format($payslip_detail['gross_pay']+$payslip_detail['commission_amount']+$payslip_detail['bonus_kpi'], '') : 0; ?></td>
				</tr>

			</tbody>
		</table>
		
		<table class="table">
			<tbody>
				<tr>
					<th  class=" thead-dark"><?php echo app_lang('deduction_list'); ?></th>
					<th  class=" thead-dark"><?php echo app_lang('hrp_amount'); ?></th>
				</tr>

				<tr class="project-overview">
					<td  width="30%" ><?php echo app_lang('income_tax'); ?></td>
					<td class="text-left"><?php echo html_entity_decode( isset($payslip_detail) ? to_decimal_format($payslip_detail['income_tax_paye']) : ''); ?></td>
				</tr>
				<tr class="project-overview">
					<td ><?php echo app_lang('hrp_insurrance'); ?></td>
					<td><?php echo isset($payslip_detail) ? to_decimal_format($payslip_detail['total_insurance']) : 0; ?></td>
				</tr>

				<tr class="project-overview">
					<td ><?php echo app_lang('hrp_deduction_manage'); ?></td>
					<td><?php echo isset($payslip_detail) ? to_decimal_format($payslip_detail['total_deductions']) : 0; ?></td>
				</tr>
				<tr class="project-overview">
					<td class="bold" ><?php echo app_lang('total'); ?></td>
					<td><?php echo isset($payslip_detail) ? to_decimal_format($payslip_detail['income_tax_paye']+$payslip_detail['total_insurance']+$payslip_detail['total_deductions']) : 0; ?></td>
				</tr>
			</tbody>
		</table>
		

	</div>

	<div class="col-md-6">
		<table class="table">
			<tbody>
				<tr class="project-overview">
					<td ><?php echo app_lang('ps_net_pay'); ?></td>
					<td><?php echo isset($payslip_detail) ? to_decimal_format($payslip_detail['net_pay']) : 0; ?></td>
				</tr>
				
			</tbody>
		</table>
		
	</div>

</div>
