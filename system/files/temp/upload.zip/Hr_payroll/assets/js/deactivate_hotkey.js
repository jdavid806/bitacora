$(function () {
  "use strict";

  $.Shortcuts.stop();
  
});