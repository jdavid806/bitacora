<script type="text/javascript">
	$(document).ready(function () {
		"use strict";
		$(".select2").select2();
	});
</script>