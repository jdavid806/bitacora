<script type="text/javascript">
    $(document).ready(function () {
        "use strict"; 
        
        $("#signin-form").appForm({ajaxSubmit: false, isModal: false});
    });
</script>   