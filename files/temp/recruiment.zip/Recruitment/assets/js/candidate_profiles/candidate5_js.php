<script type="text/javascript">
	(function($) {
		"use strict";  
		setDatePicker(".init-datepicker-fi-birthday<?php echo html_entity_decode($key) ?>");
	})(jQuery);
</script>