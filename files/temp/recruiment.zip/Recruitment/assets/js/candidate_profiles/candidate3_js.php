<script type="text/javascript">
	(function($) {
		"use strict";  
		setDatePicker(".init-datepicker-literacy-from-date<?php echo html_entity_decode($key) ?>");
		setDatePicker(".init-datepicker-literacy-to-date<?php echo html_entity_decode($key) ?>");
	})(jQuery); 
</script>