<script type="text/javascript">
	(function($) {
		"use strict";
		setDatePicker(".init-datepicker-from-date<?php echo html_entity_decode($key) ?>");
		setDatePicker(".init-datepicker-to-date<?php echo html_entity_decode($key) ?>");
	})(jQuery);
</script>