<script type="text/javascript">
	(function($) {
		"use strict";  
		setDatePicker(".init-datepicker-from-date0");
		setDatePicker(".init-datepicker-to-date0");
	})(jQuery); 
</script>