<script type="text/javascript">
	(function($) {
		"use strict";  
		setDatePicker(".init-datepicker-literacy-from-date0");
		setDatePicker(".init-datepicker-literacy-to-date0");
	})(jQuery);
</script>