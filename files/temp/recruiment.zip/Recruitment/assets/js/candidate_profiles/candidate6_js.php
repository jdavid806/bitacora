<script type="text/javascript">
	(function($) {
		"use strict";  
		setDatePicker(".init-datepicker-fi-birthday0");
	})(jQuery); 
</script>