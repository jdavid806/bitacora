<?php //copy from default_lang.php file and update
$lang["re_recruitments"] = "Recruitments";


return $lang;