
<style type="text/css">
.width-100-height-55{
	width:100%;height:55px;
}
.height-27{
	height:27px;
}
.height-28{
	height:28px;
}
.width-25-height-27{
	width:25%;
	height:27px;
}
.width-25-height-27-text-align{
	width:25%;
	height:27px;
	text-align:left;
}
.width-25-height-28{
	width:25%;
	height:28px;
}

</style>
<table border="1" class="width-100-height-55">
	<tbody>
		<tr class="height-27">
			<td class="width-25-height-27-text-align"><strong>Salary/Allowance</strong></td>
			<td class="width-25-height-27"><strong>Amount</strong></td>
			<td class="width-25-height-27"><strong>Effective date</strong></td>
			<td class="width-25-height-27"><strong>Note</strong></td>
		</tr>
		<tr class="height-27">
			<td class="width-25-height-28"><span>AL1</span></td>
			<td class="width-25-height-28"><span>1,000.00</span></td>
			<td class="width-25-height-28"><span>2021-08-02</span></td>
			<td class="width-25-height-28">aa</td>
		</tr>
	</tbody>
</table>