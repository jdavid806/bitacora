<script>
	
	$(document).ready(function () {
		'use strict';
		
		$("#dependent_person .select2").select2();
		setDatePicker("#dependent_person #start_month, #dependent_person #end_month, #dependent_person #dependent_bir");
		
	});
</script>

