<?php //copy from default_lang.php file and update

$lang["mailbox_example"] = "Example";

return $lang;