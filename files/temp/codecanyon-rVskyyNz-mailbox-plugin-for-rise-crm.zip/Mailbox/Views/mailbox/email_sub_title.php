<div class="bg-white p15 pl0">
    <span class="text-off"><?php echo app_lang("created") . ": "; ?></span>
    <?php echo format_to_relative_time($email_info->created_at); ?> 
</div>